Imports Microsoft.SPOT
Imports Microsoft.SPOT.Hardware
Imports SecretLabs.NETMF.Hardware
Imports SecretLabs.NETMF.Hardware.Netduino
Imports Toolbox.NETMF.Hardware

'  Copyright 2011-2012 Stefan Thoolen (http://netmftoolbox.codeplex.com/)
'
'  Licensed under the Apache License, Version 2.0 (the "License");
'  you may not use this file except in compliance with the License.
'  You may obtain a copy of the License at
'
'      http://www.apache.org/licenses/LICENSE-2.0
'
'  Unless required by applicable law or agreed to in writing, software
'  distributed under the License is distributed on an "AS IS" BASIS,
'  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
'  See the License for the specific language governing permissions and
'  limitations under the License.
Module Module1

    Sub Main()
        ' The Tmp36-sensor is connected to analog pin 4
        Dim TemperatureSensor As Tmp36 = New Tmp36(Pins.GPIO_PIN_A4)

        Do
            Dim celcius As Double = TemperatureSensor.Temperature
            Dim kelvin As Double = celcius + 273.15
            Dim fahrenheit As Double = (celcius * 1.8) + 32.0

            Debug.Print("Current temperature: " + celcius.ToString() + " celcius / " + kelvin.ToString() + " kelvin / " + fahrenheit.ToString() + " fahrenheit")
            Thread.Sleep(1000)
        Loop


    End Sub

End Module
